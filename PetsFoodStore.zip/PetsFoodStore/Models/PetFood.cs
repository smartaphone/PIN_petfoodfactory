﻿namespace PetsFoodStore.Models
{
    public class PetFood
    {
        public int Id { get; set; }
        public string Ime { get; set; }
        public string Opis { get; set; }
        public string Namjena { get; set; }
        public DateTime DatumDodavanja { get; set; }
    }
}
