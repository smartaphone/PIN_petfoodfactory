using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PetsFoodStore.Areas.Identity.Pages
{
    public class _ValidationScriptsPartialModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
