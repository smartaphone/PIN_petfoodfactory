using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PetsFoodStore.Areas.Identity.Pages
{
    public class _ViewImportsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
