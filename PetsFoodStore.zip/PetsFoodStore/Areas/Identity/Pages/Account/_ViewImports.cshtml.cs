using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PetsFoodStore.Areas.Identity.Pages.Account
{
    public class _ViewImportsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
