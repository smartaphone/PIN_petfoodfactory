﻿[assembly: HostingStartup(typeof(PetsFoodStore.Areas.Identity.IdentityHostingStartup))]
namespace PetsFoodStore.Areas.Identity
{
    public class IdentityHostingStartup : IHostingStartup
    {
        public void Configure(IWebHostBuilder builder)
        {
            builder.ConfigureServices((context, services) =>
            {
            });
        }
    }
}
